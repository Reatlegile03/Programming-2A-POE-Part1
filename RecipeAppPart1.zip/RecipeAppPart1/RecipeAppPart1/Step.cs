﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeAppPart1
{
    internal class Step
    {
       //get and set methods for Desciption
        public string Description { get; set; }
    }
}
