﻿namespace RecipeAppPart1
{
    internal class Recipe
    {
        //declarations
        private Ingredient[] ingredients;
        private Step[] steps;
        private double scale = 1.0;

        //method for the user to enter the details
        public void EnterDetails()
        {
            // declarations and inputs



            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());
            ingredients = new Ingredient[ingredientCount];

            for (int i = 0; i < ingredientCount; i++)
            {

                Console.WriteLine($"Enter details for ingredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit: ");
                string unit = Console.ReadLine();
                ingredients[i] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };

            }

            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());
            steps = new Step[stepCount];

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                Console.Write("Description: ");
                string description = Console.ReadLine();
                steps[i] = new Step { Description = description };
            }

            Console.WriteLine("All Details Captured Successfully");

        }


        //method to display the recipe
        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            if (ingredients != null && ingredients.Length > 0)
            {
                foreach (var ingredient in ingredients)
                {
                    Console.WriteLine($"{ingredient.Quantity * scale} {ingredient.Unit} of {ingredient.Name}");
                }
            }
            else
            {
                Console.WriteLine("No ingredients provided.");
            }

            Console.WriteLine("Steps:");
            if (steps != null && steps.Length > 0)
            {
                for (int i = 0; i < steps.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {steps[i].Description}");
                }
            }
            else
            {
                Console.WriteLine("No steps provided.");
            }




        }
    

        //method to scale the recipe
        public void ScaleRecipe(double factor)
        {
            scale = factor;
        }

        //method to reset the scale
        public void ResetScale()
        {
            scale = 1.0;
            Console.WriteLine("Quantities reset to original values");
        }

        //method to clear recipe
        public void ClearRecipe()
        {
            ingredients = null;
            steps = null;
            scale = 1.0;

            Console.WriteLine("All Data Cleared");
        }

        //method to exit the application
        public void ExitApplication()
        {
            Console.WriteLine("Thank You For Using Recipe App!");
        }


























    }
}
